package cursoapp.telefonica.com.bundleactivityintent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void aSumar(View v){
        EditText num1=(EditText)findViewById(R.id.numero1);
        EditText num2=(EditText)findViewById(R.id.numero2);
        int x=Integer.parseInt(num1.getText().toString());
        int y=Integer.parseInt(num2.getText().toString());
        Intent intent=new Intent(this,SumarActivity.class);
        intent.putExtra("numero1",x);
        intent.putExtra("numero2",y);
      // startActivity(intent);
        startActivityForResult(intent,0);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        TextView respuesta=(TextView)findViewById(R.id.respuesta);

        if(Activity.RESULT_CANCELED==resultCode){
            respuesta.setText("no hay respuesta");
        }
        if(Activity.RESULT_OK==resultCode){
            respuesta.setText(data.getStringExtra("fecha"));
        }
    }

    public void responder_intent(View v){
       Intent intent =getIntent();
        //intent.set
       // intent.putExtra("respuesta","hola mundo");
        Bundle b=new Bundle();
        b.putString("respuesta","hola mundo");
        intent.putExtras(b);
        setResult(Activity.RESULT_OK,intent);

        finish();
    }
}
