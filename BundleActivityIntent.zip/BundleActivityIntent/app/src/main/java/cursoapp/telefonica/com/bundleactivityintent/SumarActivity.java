package cursoapp.telefonica.com.bundleactivityintent;

import android.app.Activity;
import android.content.Intent;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

public class SumarActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sumar);
        TextView resultado=(TextView)findViewById(R.id.resulta_suma);
        Bundle bundle=getIntent().getExtras();
        int numero1=bundle.getInt("numero1");
        int numero2=bundle.getInt("numero2");
        resultado.setText("el resultado de la suma es: "+(numero1+numero2));

    }

    public void terminar(View v){

        finish();
    }

    public void salir(View v){

        Date date=new Date();
        TimeZone tz=TimeZone.getTimeZone("Europe/Paris");
        SimpleDateFormat sdf=new SimpleDateFormat("HH:mm");
        sdf.setTimeZone(tz);
        String hora=sdf.format(date);

        sdf.format(date);
        Intent intent=new Intent();
        intent.putExtra("fecha",hora);
        setResult(Activity.RESULT_OK,intent);

        finish();

    }
}
