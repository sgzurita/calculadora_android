package cursoapp.telefonica.com.dialogos;

import android.app.Dialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class CalculosActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculos);
        Intent intent = getIntent();
        ArrayList<Double> notas = (ArrayList<Double>) intent.getSerializableExtra("notas");
        TextView tvMedia = (TextView) findViewById(R.id.tvMedia);
        TextView tvAprobados = (TextView) findViewById(R.id.tvAprobados);
        tvMedia.setText("Nota media:" + media(notas));
        tvAprobados.setText("Aprobados: " + probados(notas));


    }

    private double probados(ArrayList<Double> notas) {
        double total = 0;
        for (double nota : notas) {
            if (nota >= 5) {
                total++;
            }
        }
        return total;
    }

    private double media(ArrayList<Double> notas) {
        double result = 0;
        for (double nota : notas) {
            result += nota;
        }
        DecimalFormat df = new DecimalFormat("0.00");
        result = Double.parseDouble(df.format(result / notas.size()));
        return result;
    }


    public void salir(View v) {

        AlertDialog.Builder cuadro = new AlertDialog.Builder(this);
        cuadro.setMessage("Desea salir de la activida");

        cuadro.setPositiveButton(android.R.string.yes, new Dialog.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {


                CalculosActivity.this.finish();

            }
        });

        cuadro.setNegativeButton(android.R.string.no, null);

        cuadro.show();
    }

}
